from django.db import models
from django.contrib.auth.models import User

class Tarefa(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # Relaciona a tarefa ao usuário
    disciplina = models.CharField(max_length=100)
    tipo_tarefa = models.CharField(max_length=100)
    data_entrega = models.DateField()
    descricao = models.TextField()
    concluida = models.BooleanField(default=False)

    def __str__(self):
        return self.disciplina

from django.db import models

class Nota(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    titulo = models.CharField(max_length=100)
    descricao = models.TextField()
    data_criacao = models.DateTimeField(auto_now_add=True)
   

    def __str__(self):
        return self.titulo

class Prova(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    disciplina = models.CharField(max_length=100)
    data = models.CharField(max_length=200)
    conteudo = models.CharField(max_length=200)
    nota = models.CharField(max_length=100)
    anotacoes = models.CharField(max_length=200)
    data_criacao = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.disciplina