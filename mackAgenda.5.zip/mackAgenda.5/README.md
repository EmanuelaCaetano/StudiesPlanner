#instalar Django

#ir para a pasta correta

#python3 -m venv venv

#source venv/bin/activate  ouuuu  venv\Scripts\activate

#python manage.py makemigrations

#python manage.py migrate

#python manage.py runserver
